setwd("C:\\Users\\hrind\\OneDrive\\Desktop\\IT24104205")

x<-rnorm(25,mean=45,sd=2)
t.test(x,mu=46,alternative="less")
